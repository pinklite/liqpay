<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{liqpay}prestashop>liqpay_533dc5e4d3d16346aec8221b313c0a7c'] = 'Прием платежей через систему LiqPay';
$_MODULE['<{liqpay}prestashop>liqpay_fa214007826415a21a8456e3e09f999d'] = 'Внимание! Все настройки будут удалены. Продолжить?';
$_MODULE['<{liqpay}prestashop>liqpay_10dcd2db95dac14ac1c6bb821915c246'] = 'Укажите пароль (merchant_pass)  и уникальный код продавца (merchant_id)';
$_MODULE['<{liqpay}prestashop>liqpay_49d3f46e1bb439e8cfe82067a7346289'] = 'Необходимо указать код продавца (merchant_id)';
$_MODULE['<{liqpay}prestashop>liqpay_c4d12d07b81b2d8ce4a0c4bbe1a8bb59'] = 'Необходимо указать пароль продавца(merchant_pass)';
$_MODULE['<{liqpay}prestashop>liqpay_e0aa021e21dddbd6d8cecec71e9cf564'] = 'Да';
$_MODULE['<{liqpay}prestashop>liqpay_c888438d14855d7d96a2724ee9c306bd'] = 'Настройки обновлены';
$_MODULE['<{liqpay}prestashop>liqpay_c4c0da756139dd27247bc33f44376cff'] = 'Этот модуль позволяет принимать платежи через систему LiqPay (Приват Банк)';
$_MODULE['<{liqpay}prestashop>liqpay_d5937eabe75e1961eda5309200bfbe5e'] = 'Вам необходимо зарегестрироваться на сайте';
$_MODULE['<{liqpay}prestashop>liqpay_5dd532f0a63d89c5af0243b74732f63c'] = 'Контактная информация';
$_MODULE['<{liqpay}prestashop>liqpay_4d0a3b2765d9889e57d02a0bc51fc13a'] = 'Укажите пароль (merchant_pass)  и уникальный код продавца (merchant_id)';
$_MODULE['<{liqpay}prestashop>liqpay_229a7ec501323b94db7ff3157a7623c9'] = 'Код продавца (merchant_id)';
$_MODULE['<{liqpay}prestashop>liqpay_315f3c78ea54c8dadb082acc328dd5bd'] = 'Пароль (merchant_pass)';
$_MODULE['<{liqpay}prestashop>liqpay_b17f3f4dcf653a5776792498a9b44d6a'] = 'Обновить настройки';
$_MODULE['<{liqpay}prestashop>liqpay_39290be1b0f41edaebf1a7be5629d5c0'] = 'Оплатить через систему LiqPay (Visa / Mastercard)';
$_MODULE['<{liqpay}prestashop>liqpay_f5bb84824c03075e1eef6c1993697cbb'] = 'Оплатита через систему LiqPay (Visa / Mastercard)';
