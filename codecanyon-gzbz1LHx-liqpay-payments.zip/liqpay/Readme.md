This module will let you accept payment through Liqpay - Popular payment system in Ukraine!


<strong>Setting up LiqPay module</strong>

In order to start accepting payment through LiqPay you need:

1.Create <a href="https://www.liqpay.com/en" target="_blank"> LiqPay </a>account (phone number).   
2. Create store in Business tab.
3. Get Public and Private keys.

Use Public and Private keys to enter them in module's appropriate fields. Then turn on Test Mode switch to test your, created store in LiqPay, to test payments.    

<strong>The benefits for Merchants </strong>

Accept credit and debit card payments on your store from your customers in Ukraine and Russia. 
Increase trust into your store to customers from Ukraine and Russia by providing secure and popular payment option.
You can add any bank card to your Liqpay account and get paid instantly.

<strong> Main features LiqPay module   </strong>

- 1-click payment.
 - Accepting secure payment from Liqpay account or Visa or MasterCard cards.
 - Easy one click setup.
 - Sandbox mode option for testing 
 

 <strong>The benefits for customers </strong>

It is backup by biggest bank in Ukraine - Privatbank.
Payment support extra security layers for bank cards: Verified by Visa, and MasterCard SecureCode.
After payment get notification on your phone through SMS or in Liqpay App.
Reliability of LiqPay has been confirmed with  Verified by Visa, and MasterCard SecureCode certificates.